import pygame
import math
import numpy as np

# Initialize Pygame
pygame.init()

# Get monitor resolution
info = pygame.display.Info()
SCREEN_WIDTH = info.current_w
SCREEN_HEIGHT = info.current_h
HALF_WIDTH = SCREEN_WIDTH // 2
HALF_HEIGHT = SCREEN_HEIGHT // 2

# Constants
FOV = math.pi / 3  # Field of view
HALF_FOV = FOV / 2
MAX_DEPTH = 20
MOVE_SPEED = 0.1
ROTATION_SPEED = 0.05
MOUSE_SENSITIVITY = 0.002

# Colors
SKY_COLOR = (100, 150, 255)
GROUND_COLOR = (60, 60, 60)
WALL_COLORS = [
    (200, 50, 50),    # Red
    (50, 200, 50),    # Green
    (50, 50, 200),    # Blue
    (200, 200, 50),   # Yellow
    (200, 50, 200),   # Purple
    (50, 200, 200),   # Cyan
]

# Create fullscreen screen
screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT), pygame.FULLSCREEN)
pygame.display.set_caption("Python Doom-Style Game - Enhanced")
clock = pygame.time.Clock()

# Hide mouse cursor
pygame.mouse.set_visible(False)
pygame.event.set_grab(True)

# Enhanced map with more details
MAP = [
    [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1],
    [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
    [1, 0, 2, 2, 0, 0, 0, 0, 3, 3, 0, 1],
    [1, 0, 2, 0, 0, 0, 0, 0, 0, 3, 0, 1],
    [1, 0, 0, 0, 0, 4, 4, 0, 0, 0, 0, 1],
    [1, 0, 0, 0, 4, 0, 0, 4, 0, 0, 0, 1],
    [1, 0, 0, 0, 4, 0, 0, 4, 0, 0, 0, 1],
    [1, 0, 5, 0, 0, 4, 4, 0, 0, 6, 0, 1],
    [1, 0, 5, 5, 0, 0, 0, 0, 6, 6, 0, 1],
    [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
    [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
    [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1],
]

MAP_SIZE = len(MAP)

# Player position and direction
player_x, player_y = 1.5, 1.5
player_angle = 0

# Movement smoothing
move_forward = move_backward = move_left = move_right = False
rotation_left = rotation_right = False

# Pre-calculated values for optimization
cos_table = [math.cos(i * 0.01) for i in range(628)]
sin_table = [math.sin(i * 0.01) for i in range(628)]

def cast_ray(angle):
    # Optimized raycasting with DDA algorithm
    ray_angle = angle % (2 * math.pi)
    ray_cos = math.cos(ray_angle) * 0.03
    ray_sin = math.sin(ray_angle) * 0.03
    
    # Initial position
    map_x, map_y = int(player_x), int(player_y)
    
    # Ray direction
    ray_dir_x = math.cos(ray_angle)
    ray_dir_y = math.sin(ray_angle)
    
    # Length of ray from current position to next x or y-side
    delta_dist_x = abs(1 / ray_dir_x) if ray_dir_x != 0 else 1e30
    delta_dist_y = abs(1 / ray_dir_y) if ray_dir_y != 0 else 1e30
    
    # Direction to step in x or y direction (either +1 or -1)
    step_x = 1 if ray_dir_x >= 0 else -1
    step_y = 1 if ray_dir_y >= 0 else -1
    
    # Length of ray from one x or y-side to next x or y-side
    if ray_dir_x < 0:
        side_dist_x = (player_x - map_x) * delta_dist_x
    else:
        side_dist_x = (map_x + 1.0 - player_x) * delta_dist_x
        
    if ray_dir_y < 0:
        side_dist_y = (player_y - map_y) * delta_dist_y
    else:
        side_dist_y = (map_y + 1.0 - player_y) * delta_dist_y
    
    # Perform DDA
    hit = 0
    side = 0
    
    while hit == 0:
        # Jump to next map square, either in x-direction, or in y-direction
        if side_dist_x < side_dist_y:
            side_dist_x += delta_dist_x
            map_x += step_x
            side = 0
        else:
            side_dist_y += delta_dist_y
            map_y += step_y
            side = 1
        
        # Check if ray has hit a wall
        if 0 <= map_x < MAP_SIZE and 0 <= map_y < MAP_SIZE:
            if MAP[map_y][map_x] > 0:
                hit = MAP[map_y][map_x]
        else:
            break
    
    # Calculate distance projected on camera direction
    if side == 0:
        perp_wall_dist = (map_x - player_x + (1 - step_x) / 2) / ray_dir_x
    else:
        perp_wall_dist = (map_y - player_y + (1 - step_y) / 2) / ray_dir_y
    
    return perp_wall_dist, hit, side

def draw_3d_view():
    # Draw sky and ground with gradient
    for y in range(HALF_HEIGHT):
        # Sky gradient (darker at top)
        sky_color = [max(0, c - y // 30) for c in SKY_COLOR]
        pygame.draw.line(screen, sky_color, (0, y), (SCREEN_WIDTH, y))
        
        # Ground gradient (darker at bottom)
        ground_y = HALF_HEIGHT + y
        if ground_y < SCREEN_HEIGHT:
            ground_color = [max(0, c - y // 40) for c in GROUND_COLOR]
            pygame.draw.line(screen, ground_color, (0, ground_y), (SCREEN_WIDTH, ground_y))
    
    # Cast rays for each column on the screen with reduced resolution for performance
    ray_step = max(1, SCREEN_WIDTH // 800)  # Adaptive resolution based on screen size
    for x in range(0, SCREEN_WIDTH, ray_step):
        # Calculate ray angle
        ray_angle = player_angle - HALF_FOV + (x / SCREEN_WIDTH) * FOV
        
        # Cast ray
        distance, wall, side = cast_ray(ray_angle)
        
        # Fix fisheye effect
        distance = distance * math.cos(player_angle - ray_angle)
        
        # Calculate wall height
        wall_height = min(int(SCREEN_HEIGHT / distance), SCREEN_HEIGHT * 2)
        
        # Calculate wall position
        wall_top = max(0, (SCREEN_HEIGHT - wall_height) // 2)
        wall_bottom = min(SCREEN_HEIGHT, wall_top + wall_height)
        
        # Draw wall slice
        if wall > 0:
            color = list(WALL_COLORS[(wall - 1) % len(WALL_COLORS)])
            
            # Darken color based on distance and side
            darken_factor = max(0.2, 1 - distance / MAX_DEPTH)
            if side == 1:  # Darken y-sides for depth
                darken_factor *= 0.8
                
            color = [int(c * darken_factor) for c in color]
            
            # Draw thicker lines when using reduced resolution
            line_width = ray_step
            pygame.draw.line(screen, color, (x, wall_top), (x, wall_bottom), line_width)

def draw_minimap():
    # Draw minimap in the corner
    minimap_size = min(200, SCREEN_WIDTH // 6, SCREEN_HEIGHT // 6)
    cell_size = minimap_size // MAP_SIZE
    minimap_x = SCREEN_WIDTH - minimap_size - 10
    minimap_y = 10
    
    # Draw map background
    pygame.draw.rect(screen, (40, 40, 40), (minimap_x, minimap_y, minimap_size, minimap_size))
    
    # Draw map cells
    for y in range(MAP_SIZE):
        for x in range(MAP_SIZE):
            if MAP[y][x]:
                color_idx = (MAP[y][x] - 1) % len(WALL_COLORS)
                pygame.draw.rect(screen, WALL_COLORS[color_idx], 
                                (minimap_x + x * cell_size, 
                                 minimap_y + y * cell_size, 
                                 cell_size, cell_size))
    
    # Draw player
    player_minimap_x = minimap_x + int(player_x * cell_size)
    player_minimap_y = minimap_y + int(player_y * cell_size)
    pygame.draw.circle(screen, (255, 255, 255), (player_minimap_x, player_minimap_y), 4)
    
    # Draw player direction line
    direction_x = player_minimap_x + math.cos(player_angle) * 15
    direction_y = player_minimap_y + math.sin(player_angle) * 15
    pygame.draw.line(screen, (255, 255, 0), 
                    (player_minimap_x, player_minimap_y), 
                    (direction_x, direction_y), 2)

def draw_crosshair():
    # Draw a simple crosshair in the center
    center_x, center_y = HALF_WIDTH, HALF_HEIGHT
    pygame.draw.line(screen, (255, 255, 255), (center_x - 10, center_y), (center_x + 10, center_y), 2)
    pygame.draw.line(screen, (255, 255, 255), (center_x, center_y - 10), (center_x, center_y + 10), 2)

def main():
    global player_x, player_y, player_angle
    global move_forward, move_backward, move_left, move_right
    
    running = True
    while running:
        # Handle events
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    running = False
                elif event.key == pygame.K_w:
                    move_forward = True
                elif event.key == pygame.K_s:
                    move_backward = True
                elif event.key == pygame.K_a:
                    move_left = True
                elif event.key == pygame.K_d:
                    move_right = True
            elif event.type == pygame.KEYUP:
                if event.key == pygame.K_w:
                    move_forward = False
                elif event.key == pygame.K_s:
                    move_backward = False
                elif event.key == pygame.K_a:
                    move_left = False
                elif event.key == pygame.K_d:
                    move_right = False
            elif event.type == pygame.MOUSEMOTION:
                # Mouse look
                rel_x, rel_y = event.rel
                player_angle += rel_x * MOUSE_SENSITIVITY
        
        # Movement calculation
        move_x, move_y = 0, 0
        if move_forward:
            move_x += math.cos(player_angle) * MOVE_SPEED
            move_y += math.sin(player_angle) * MOVE_SPEED
        if move_backward:
            move_x -= math.cos(player_angle) * MOVE_SPEED
            move_y -= math.sin(player_angle) * MOVE_SPEED
        if move_left:
            move_x += math.cos(player_angle - math.pi/2) * MOVE_SPEED
            move_y += math.sin(player_angle - math.pi/2) * MOVE_SPEED
        if move_right:
            move_x += math.cos(player_angle + math.pi/2) * MOVE_SPEED
            move_y += math.sin(player_angle + math.pi/2) * MOVE_SPEED
        
        # Check collision with smoothing
        new_x = player_x + move_x
        new_y = player_y + move_y
        
        if 0 <= new_x < MAP_SIZE and 0 <= new_y < MAP_SIZE:
            if MAP[int(new_y)][int(new_x)] == 0:
                player_x, player_y = new_x, new_y
            else:
                # Try sliding along walls
                if MAP[int(new_y)][int(player_x)] == 0:
                    player_y = new_y
                elif MAP[int(player_y)][int(new_x)] == 0:
                    player_x = new_x
        
        # Draw everything
        draw_3d_view()
        draw_minimap()
        draw_crosshair()
        
        # Display FPS and controls
        fps = int(clock.get_fps())
        font = pygame.font.SysFont('Arial', 24)
        fps_text = font.render(f'FPS: {fps}', True, (255, 255, 255))
        screen.blit(fps_text, (10, 10))
        
        controls_text = font.render('WASD: Move | Mouse: Look | ESC: Quit', True, (255, 255, 255))
        screen.blit(controls_text, (10, SCREEN_HEIGHT - 30))
        
        pygame.display.flip()
        clock.tick(60)
    
    # Clean up
    pygame.mouse.set_visible(True)
    pygame.event.set_grab(False)
    pygame.quit()

if __name__ == "__main__":
    main()