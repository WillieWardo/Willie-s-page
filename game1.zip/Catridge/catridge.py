import dearpygui.dearpygui as dpg
import subprocess
import webbrowser
import threading
from pygame import mixer

# Initialize audio
try:
    mixer.init()
    mixer.music.load("data/music.mp3") 
    mixer.music.play(-1)
    mixer.music.set_volume(0.3)
except:
    print("Could not load background music")

dpg.create_context()

def open_data1():
    threading.Thread(target=lambda: subprocess.run(['python', 'data/data1.py']), daemon=True).start()

def open_data2():
    threading.Thread(target=lambda: subprocess.run(['python', 'data/data2.py']), daemon=True).start()

def open_website():
    webbrowser.open("https://example.com")

def exit_app():
    mixer.music.stop()
    dpg.stop_dearpygui()

with dpg.window(tag="Primary Window"):
    dpg.add_text("GAME MENU", color=(255, 255, 255), pos=(400, 50))
    
    dpg.add_button(
        label="DATA 1", 
        callback=open_data1,
        width=200, height=50,
        pos=(350, 150)
    )
    
    dpg.add_button(
        label="DATA 2",
        callback=open_data2, 
        width=200, height=50,
        pos=(350, 220)
    )
    
    dpg.add_button(
        label="WEBSITE",
        callback=open_website,
        width=200, height=50,
        pos=(350, 290)
    )
    
    dpg.add_button(
        label="EXIT",
        callback=exit_app,
        width=120, height=35,
        pos=(390, 380)
    )

dpg.create_viewport(
    title='rape nigger', 
    width=800, 
    height=500,
    x_pos=400,
    y_pos=200
)
dpg.setup_dearpygui()
dpg.show_viewport()
dpg.set_primary_window("Primary Window", True)
dpg.start_dearpygui()
dpg.destroy_context()