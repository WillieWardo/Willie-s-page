"""
WinForms-style Visual Designer (PySide6)

Features:
- Toolbox (Button, Label, LineEdit, CheckBox)
- Canvas built with QGraphicsView + QGraphicsScene
- Add widgets, move, resize (handles), select
- Property editor (text, geometry)
- Save/Load layout (JSON)
- Export generated PySide6 code that recreates the designed form

Requirements:
    pip install PySide6

Run:
    python winforms_designer.py

This is a focused but functional recreation of a WinForms-like designer in Python.
"""

import sys
import json
from PySide6 import QtCore, QtGui, QtWidgets

WIDGET_MAP = {
    'Button': QtWidgets.QPushButton,
    'Label': QtWidgets.QLabel,
    'LineEdit': QtWidgets.QLineEdit,
    'CheckBox': QtWidgets.QCheckBox,
}


class ResizeHandle(QtWidgets.QGraphicsRectItem):
    SIZE = 8

    def __init__(self, role, parent_widget_item):
        super().__init__(-ResizeHandle.SIZE/2, -ResizeHandle.SIZE/2, ResizeHandle.SIZE, ResizeHandle.SIZE)
        self.setBrush(QtGui.QBrush(QtCore.Qt.black))
        self.setFlag(QtWidgets.QGraphicsItem.ItemIsMovable, True)
        self.setFlag(QtWidgets.QGraphicsItem.ItemSendsGeometryChanges, True)
        self.role = role
        self.parent_item = parent_widget_item
        self.setZValue(2)

    def itemChange(self, change, value):
        if change == QtWidgets.QGraphicsItem.ItemPositionChange:
            newpos = value
            self.parent_item.handle_moved(self.role, newpos)
        return super().itemChange(change, value)


class WidgetItem(QtWidgets.QGraphicsRectItem):
    def __init__(self, widget_type: str, text: str = '', rect: QtCore.QRectF = QtCore.QRectF(0, 0, 120, 30)):
        super().__init__(rect)
        self.widget_type = widget_type
        self.setBrush(QtGui.QBrush(QtCore.Qt.white))
        self.setPen(QtGui.QPen(QtCore.Qt.gray))
        self.setFlags(QtWidgets.QGraphicsItem.ItemIsSelectable | QtWidgets.QGraphicsItem.ItemIsMovable)
        self.proxy = None
        self.create_proxy(text)
        self.handles = {}
        self.update_handles()

    def create_proxy(self, text):
        cls = WIDGET_MAP.get(self.widget_type, QtWidgets.QLabel)
        w = cls()
        # set default text where applicable
        if hasattr(w, 'setText'):
            w.setText(text or self.widget_type)
        if isinstance(w, QtWidgets.QLineEdit):
            w.setText(text or '')
        self.proxy = QtWidgets.QGraphicsProxyWidget(self)
        self.proxy.setWidget(w)
        self.update_proxy_geometry()

    def update_proxy_geometry(self):
        r = self.rect()
        self.proxy.setGeometry(r)

    def update_handles(self):
        # remove old handles
        for h in self.handles.values():
            self.scene().removeItem(h)
        self.handles.clear()
        # create 4 corner handles
        roles = ['tl', 'tr', 'bl', 'br']
        for role in roles:
            handle = ResizeHandle(role, self)
            self.handles[role] = handle
            handle.setParentItem(self)
        self.position_handles()

    def position_handles(self):
        r = self.rect()
        self.handles['tl'].setPos(r.topLeft())
        self.handles['tr'].setPos(r.topRight())
        self.handles['bl'].setPos(r.bottomLeft())
        self.handles['br'].setPos(r.bottomRight())

    def handle_moved(self, role, pos):
        # pos is in local coordinates
        r = QtCore.QRectF(self.rect())
        if role == 'tl':
            r.setTopLeft(pos)
        elif role == 'tr':
            r.setTopRight(pos)
        elif role == 'bl':
            r.setBottomLeft(pos)
        elif role == 'br':
            r.setBottomRight(pos)
        # enforce minimum size
        minw, minh = 20, 14
        if r.width() < minw:
            r.setWidth(minw)
        if r.height() < minh:
            r.setHeight(minh)
        self.prepareGeometryChange()
        self.setRect(r)
        self.update_proxy_geometry()
        self.position_handles()
        # update property editor if any
        view = self.scene().views()[0] if self.scene().views() else None
        if view and hasattr(view, 'owner') and view.owner.selected_item is self:
            view.owner.prop_panel.update_from_item(self)

    def mouseReleaseEvent(self, event):
        super().mouseReleaseEvent(event)
        # notify property panel about new geometry
        view = self.scene().views()[0] if self.scene().views() else None
        if view and hasattr(view, 'owner') and view.owner.selected_item is self:
            view.owner.prop_panel.update_from_item(self)

    def to_dict(self):
        r = self.sceneBoundingRect()
        widget = self.proxy.widget()
        text = ''
        if hasattr(widget, 'text'):
            try:
                text = widget.text()
            except Exception:
                text = ''
        return {
            'type': self.widget_type,
            'text': text,
            'x': r.x(), 'y': r.y(), 'w': r.width(), 'h': r.height()
        }

    def apply_dict(self, data):
        self.setRect(0, 0, data['w'], data['h'])
        self.setPos(data['x'], data['y'])
        # update widget text
        if self.proxy and self.proxy.widget() and hasattr(self.proxy.widget(), 'setText'):
            try:
                self.proxy.widget().setText(data.get('text', ''))
            except Exception:
                pass
        self.update_proxy_geometry()
        self.position_handles()


class DesignerView(QtWidgets.QGraphicsView):
    def __init__(self, scene, owner=None):
        super().__init__(scene)
        self.owner = owner
        self.setRenderHints(QtGui.QPainter.Antialiasing | QtGui.QPainter.SmoothPixmapTransform)
        self.setScene(scene)
        self.setAlignment(QtCore.Qt.AlignLeft | QtCore.Qt.AlignTop)
        self.setBackgroundBrush(QtGui.QBrush(QtCore.Qt.lightGray))
        self.setDragMode(QtWidgets.QGraphicsView.RubberBandDrag)

    def mousePressEvent(self, event):
        super().mousePressEvent(event)
        item = self.itemAt(event.position().toPoint())
        # determine clicked WidgetItem
        clicked_widget = None
        if item:
            # climb up to WidgetItem
            while item and not isinstance(item, WidgetItem):
                item = item.parentItem()
            clicked_widget = item
        self.owner.select_item(clicked_widget)


class PropertyPanel(QtWidgets.QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        layout = QtWidgets.QFormLayout(self)
        self.type_label = QtWidgets.QLabel('-')
        self.text_edit = QtWidgets.QLineEdit()
        geom_hbox = QtWidgets.QHBoxLayout()
        self.x_spin = QtWidgets.QSpinBox(); self.x_spin.setMaximum(10000)
        self.y_spin = QtWidgets.QSpinBox(); self.y_spin.setMaximum(10000)
        self.w_spin = QtWidgets.QSpinBox(); self.w_spin.setMaximum(10000)
        self.h_spin = QtWidgets.QSpinBox(); self.h_spin.setMaximum(10000)
        geom_hbox.addWidget(QtWidgets.QLabel('X')); geom_hbox.addWidget(self.x_spin)
        geom_hbox.addWidget(QtWidgets.QLabel('Y')); geom_hbox.addWidget(self.y_spin)
        geom_hbox.addWidget(QtWidgets.QLabel('W')); geom_hbox.addWidget(self.w_spin)
        geom_hbox.addWidget(QtWidgets.QLabel('H')); geom_hbox.addWidget(self.h_spin)
        self.apply_btn = QtWidgets.QPushButton('Apply')
        self.apply_btn.clicked.connect(self.apply_to_item)

        layout.addRow('Type:', self.type_label)
        layout.addRow('Text:', self.text_edit)
        layout.addRow('Geometry:', geom_hbox)
        layout.addRow(self.apply_btn)

        self._item = None

    def update_from_item(self, item: WidgetItem | None):
        self._item = item
        if not item:
            self.type_label.setText('-')
            self.text_edit.setText('')
            self.x_spin.setValue(0); self.y_spin.setValue(0); self.w_spin.setValue(0); self.h_spin.setValue(0)
            return
        self.type_label.setText(item.widget_type)
        w = item.proxy.widget()
        txt = ''
        if hasattr(w, 'text'):
            try:
                txt = w.text()
            except Exception:
                txt = ''
        self.text_edit.setText(txt)
        rect = item.sceneBoundingRect()
        self.x_spin.setValue(int(rect.x()))
        self.y_spin.setValue(int(rect.y()))
        self.w_spin.setValue(int(rect.width()))
        self.h_spin.setValue(int(rect.height()))

    def apply_to_item(self):
        if not self._item:
            return
        text = self.text_edit.text()
        w = self._item.proxy.widget()
        if hasattr(w, 'setText'):
            try:
                w.setText(text)
            except Exception:
                pass
        x = self.x_spin.value(); y = self.y_spin.value(); w_ = self.w_spin.value(); h_ = self.h_spin.value()
        self._item.setRect(0, 0, w_, h_)
        self._item.setPos(x, y)
        self._item.update_proxy_geometry()
        self._item.position_handles()


class MainWindow(QtWidgets.QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle('WinForms-like Designer (Python)')
        self.resize(1200, 800)

        # central scene/view
        self.scene = QtWidgets.QGraphicsScene()
        self.view = DesignerView(self.scene, owner=self)
        self.setCentralWidget(self.view)

        # toolbox dock
        toolbox = QtWidgets.QDockWidget('Toolbox', self)
        tw = QtWidgets.QListWidget()
        for k in WIDGET_MAP.keys():
            tw.addItem(k)
        tw.itemDoubleClicked.connect(self.toolbox_add)
        toolbox.setWidget(tw)
        self.addDockWidget(QtCore.Qt.LeftDockWidgetArea, toolbox)
        self.toolbox_list = tw

        # properties dock
        prop = QtWidgets.QDockWidget('Properties', self)
        self.prop_panel = PropertyPanel()
        prop.setWidget(self.prop_panel)
        self.addDockWidget(QtCore.Qt.RightDockWidgetArea, prop)

        # output / logs
        out = QtWidgets.QDockWidget('Output', self)
        self.output_text = QtWidgets.QTextEdit(); self.output_text.setReadOnly(True)
        out.setWidget(self.output_text)
        self.addDockWidget(QtCore.Qt.BottomDockWidgetArea, out)

        # toolbar and menu
        self.build_menu_toolbar()

        self.selected_item = None

    def build_menu_toolbar(self):
        menubar = self.menuBar()
        file_menu = menubar.addMenu('File')
        new_act = QtGui.QAction('New', self); new_act.triggered.connect(self.action_new)
        open_act = QtGui.QAction('Open...', self); open_act.triggered.connect(self.action_open)
        save_act = QtGui.QAction('Save...', self); save_act.triggered.connect(self.action_save)
        export_act = QtGui.QAction('Export Py', self); export_act.triggered.connect(self.action_export)
        file_menu.addAction(new_act); file_menu.addAction(open_act); file_menu.addAction(save_act); file_menu.addAction(export_act)

        tb = self.addToolBar('Main')
        tb.addAction(new_act); tb.addAction(open_act); tb.addAction(save_act); tb.addAction(export_act)

    def toolbox_add(self, item):
        typ = item.text()
        # add item centered in view
        view_center = self.view.mapToScene(self.view.viewport().rect().center())
        wi = WidgetItem(typ)
        self.scene.addItem(wi)
        wi.setPos(view_center - QtCore.QPointF(wi.rect().width()/2, wi.rect().height()/2))
        wi.update_proxy_geometry()
        wi.update_handles()
        self.output_text.append(f'Added {typ}')

    def select_item(self, item: WidgetItem | None):
        # deselect previous
        if self.selected_item and self.selected_item is not item:
            self.selected_item.setPen(QtGui.QPen(QtCore.Qt.gray))
        self.selected_item = item
        if item:
            item.setPen(QtGui.QPen(QtCore.Qt.blue, 2))
            self.prop_panel.update_from_item(item)
        else:
            self.prop_panel.update_from_item(None)

    def action_new(self):
        self.scene.clear()
        self.output_text.clear()
        self.output_text.append('New document')

    def action_save(self):
        name, _ = QtWidgets.QFileDialog.getSaveFileName(self, 'Save layout', filter='JSON Files (*.json)')
        if not name:
            return
        arr = []
        for it in self.scene.items():
            if isinstance(it, WidgetItem):
                arr.append(it.to_dict())
        with open(name, 'w', encoding='utf-8') as f:
            json.dump(arr, f, indent=2)
        self.output_text.append(f'Saved layout to {name}')

    def action_open(self):
        name, _ = QtWidgets.QFileDialog.getOpenFileName(self, 'Open layout', filter='JSON Files (*.json)')
        if not name:
            return
        with open(name, 'r', encoding='utf-8') as f:
            data = json.load(f)
        self.scene.clear()
        for item in data:
            wi = WidgetItem(item['type'])
            self.scene.addItem(wi)
            wi.apply_dict(item)
            wi.update_handles()
        self.output_text.append(f'Loaded layout from {name}')

    def action_export(self):
        # generate PySide6 code that recreates the layout
        elements = []
        for it in self.scene.items():
            if isinstance(it, WidgetItem):
                elements.append(it.to_dict())
        code = self.generate_pyside_code(elements)
        name, _ = QtWidgets.QFileDialog.getSaveFileName(self, 'Export Python', filter='Python Files (*.py)')
        if not name:
            return
        with open(name, 'w', encoding='utf-8') as f:
            f.write(code)
        self.output_text.append(f'Exported Python to {name}')

    def generate_pyside_code(self, elements):
        header = 'from PySide6 import QtWidgets, QtCore\n\nclass GeneratedForm(QtWidgets.QWidget):\n    def __init__(self):\n        super().__init__()\n        self.setWindowTitle("Generated Form")\n        self.setGeometry(100, 100, 800, 600)\n\n'
        body = '        # widgets\n'
        for i, e in enumerate(elements):
            var = f'w{i}'
            t = e['type']
            text = e.get('text', '').replace('"', '\\"')
            x, y, w, h = int(e['x']), int(e['y']), int(e['w']), int(e['h'])
            if t == 'Button':
                body += f'        {var} = QtWidgets.QPushButton("{text}", self)\n'
            elif t == 'Label':
                body += f'        {var} = QtWidgets.QLabel("{text}", self)\n'
            elif t == 'LineEdit':
                body += f'        {var} = QtWidgets.QLineEdit(self)\n        {var}.setText("{text}")\n'
            elif t == 'CheckBox':
                body += f'        {var} = QtWidgets.QCheckBox("{text}", self)\n'
            else:
                body += f'        {var} = QtWidgets.QLabel("{text}", self)\n'
            body += f'        {var}.setGeometry({x}, {y}, {w}, {h})\n\n'
        footer = '\nif __name__ == "__main__":\n    import sys\n    app = QtWidgets.QApplication(sys.argv)\n    win = GeneratedForm()\n    win.show()\n    sys.exit(app.exec())\n'
        return header + body + footer


if __name__ == '__main__':
    app = QtWidgets.QApplication(sys.argv)
    mw = MainWindow()
    mw.show()
    sys.exit(app.exec())