import sys
from PyQt5.QtCore import *
from PyQt5.QtWidgets import *
from PyQt5.QtWebEngineWidgets import *
from PyQt5.QtMultimedia import QMediaPlayer, QMediaContent
from PyQt5.QtMultimediaWidgets import QVideoWidget

class MainWindow(QMainWindow):
    def __init__(self):
        super(MainWindow, self).__init__()
        self.browser = QWebEngineView()
        self.setCentralWidget(self.browser)
        self.showMaximized()

        # Load the local index.html file
        try:
            self.browser.setUrl(QUrl.fromLocalFile(QFileInfo('index.html').absoluteFilePath()))
        except Exception as e:
            print(f"Error loading index.html: {e}")

        # Navbar setup
        navbar = QToolBar()
        self.addToolBar(navbar)

        # Back button
        back_btn = QAction('Back', self)
        back_btn.triggered.connect(self.browser.back)
        navbar.addAction(back_btn)

        # Forward button
        forward_btn = QAction('Forwart', self)
        forward_btn.triggered.connect(self.browser.forward)
        navbar.addAction(forward_btn)

        # Reload button
        reload_btn = QAction('Reloat', self)
        reload_btn.triggered.connect(self.browser.reload)
        navbar.addAction(reload_btn)

        # Home button
        home_btn = QAction('Hame', self)
        home_btn.triggered.connect(self.navigate_home)
        navbar.addAction(home_btn)

        # Bookmark button
        bookmark_btn = QAction('Bookmerk', self)
        bookmark_btn.triggered.connect(self.add_bookmark)
        navbar.addAction(bookmark_btn)

        # URL bar
        self.url_bar = QLineEdit()
        self.url_bar.returnPressed.connect(self.navigate_to_url)
        navbar.addWidget(self.url_bar)

        # Load finished
        self.browser.urlChanged.connect(self.update_url)
        self.browser.loadFinished.connect(self.inject_javascript)

        # Bookmarks storage
        self.bookmarks = []

        # Bookmark menu
        self.bookmark_menu = QMenu("Bookmarks", self)
        navbar.addAction(self.bookmark_menu.menuAction())

        # Set up the background music
        self.setup_background_music()

    def navigate_home(self):
        self.browser.setUrl(QUrl('file:///C:/Users/Liqui/Desktop/serbain browser/index.html'))  # Set to Bing

    def navigate_to_url(self):
        url = self.url_bar.text()
        if not url.startswith('http'):
            url = 'http://' + url
        self.browser.setUrl(QUrl(url))

    def update_url(self, q):
        self.url_bar.setText(q.toString())

    def add_bookmark(self):
        current_url = self.browser.url().toString()
        if current_url not in self.bookmarks:
            self.bookmarks.append(current_url)
            self.update_bookmark_menu()
            QMessageBox.information(self, "Oznaka je dodata", f"{current_url} dodat je u oznake")
        else:
            QMessageBox.warning(self, "Bookmark Exists", f"{current_url} is already in bookmarks.")

    def update_bookmark_menu(self):
        self.bookmark_menu.clear()  # Clear existing menu items
        for url in self.bookmarks:
            action = QAction(url, self)
            action.triggered.connect(lambda checked, url=url: self.browser.setUrl(QUrl(url)))
            self.bookmark_menu.addAction(action)

    def inject_javascript(self):
        # Replace Bing's logo with a custom image after a delay
        js_code = """
        console.log("Waiting to replace the Bing logo...");
        setTimeout(function() {
            var logo = document.querySelector('img');  // Adjust this selector if necessary
            if (logo) {
                logo.src = 'https://i.ytimg.com/vi/99EMzTYikOg/maxresdefault.jpg?sqp=-oaymwEmCIAKENAF8quKqQMa8AEB-AH-CYAC0AWKAgwIABABGBMgXyh_MA8=&rs=AOn4CLBRTEmM9lhrX-jScVgQpE2vjzJfoQ';  // Replace with your custom icon URL
                logo.srcset = '';  // Clear srcset to avoid multiple resolutions
                logo.alt = 'My Custom Logo';  // Optional alt text
                console.log("Logo replaced successfully!");
            } else {
                console.log("Logo not found!");
            }
        }, 3000);  // 3-second delay to ensure the page is fully loaded
        """
        self.browser.page().runJavaScript(js_code)

    def setup_background_music(self):
        self.media_player = QMediaPlayer()
        url = QUrl.fromLocalFile(QFileInfo('background_music.mp3').absoluteFilePath())  # Use your own music file path
        content = QMediaContent(url)
        self.media_player.setMedia(content)
        self.media_player.setVolume(30)  # Set volume (0 to 100)
        self.media_player.play()

        # Loop the music
        self.media_player.mediaStatusChanged.connect(self.loop_music)

    def loop_music(self, status):
        if status == QMediaPlayer.EndOfMedia:
            self.media_player.play()  # Replay when the music ends

if __name__ == "__main__":
    app = QApplication(sys.argv)
    QApplication.setApplicationName('sarbian stong')
    window = MainWindow()
    window.show()  # Show the window
    sys.exit(app.exec_())  # Exit application
